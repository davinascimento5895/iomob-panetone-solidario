const o="/assets/logo-rotary-BnKKW_ap.svg";export{o as l};
